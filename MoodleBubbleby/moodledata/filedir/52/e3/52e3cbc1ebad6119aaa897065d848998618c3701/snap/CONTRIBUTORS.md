#Contributors

##Open LMS
Stuart Lamour, David Scotson, Guy Thomas, Corey Wallis, Mark Nielsen, Sam Chaffee

##Community

Jérôme Mouneyrac - fix issue #4 : sql error on the content course page

Snap project would like to thank:

Moodle accessibility group, University of Montana, American Foundation for the Blind for their continued help and support,
American International School, Paul Hibbitts, Lewis Carr, Heythrop College for invaluable usability feedback.

##3rd Party

All icons are by or based on icons from www.roundicons.com